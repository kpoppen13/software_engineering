package com.example.hellokittyquiz

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.createSavedStateHandle
import com.example.hellokittyquiz.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

// add some information that records the progress on my log
private const val TAG = "Main Activity Recording"


class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var nextButton: Button
    private lateinit var previousButton: Button

    private lateinit var binding: ActivityMainBinding

    private val quizViewModel: QuizViewModel by viewModels()
    private val cheatLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val wasCheater = result.data?.getBooleanExtra(EXTRA_ANSWER_SHOWN, false) ?: false
            if (wasCheater) quizViewModel.isCheater = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "OnCreate(Bundle?) called")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d(TAG, "Got a QuizViewModel: $quizViewModel")

        //trueButton = findViewById(R.id.TrueButton)
        //falseButton = findViewById(R.id.FalseButton)

        nextButton = findViewById(R.id.NextButton)

        binding.TrueButton.setOnClickListener { view: View ->

            binding.TrueButton.isEnabled = false
            binding.FalseButton.isEnabled = false
            quizViewModel.setAnswered(true)
            checkAnswer(true)
        }

        binding.FalseButton.setOnClickListener {view: View ->
            binding.TrueButton.isEnabled = false
            binding.FalseButton.isEnabled = false
            quizViewModel.setAnswered(true)
            checkAnswer(false)

        }

        binding.NextButton.setOnClickListener {
            quizViewModel.moveToNext()
            repeatAnswers()
            updateQuestion()
        }

        binding.cheatButton.setOnClickListener {
            val answerIsTrue = quizViewModel.currentQuestionAnswer
            val intent = CheatActivity.newIntent(this@MainActivity, answerIsTrue, quizViewModel.isCheater)
            cheatLauncher.launch(intent)
        }
        updateQuestion()

        binding.textQuestion.setOnClickListener{
            quizViewModel.moveToNext()
            updateQuestion()
        }


        updateQuestion()
        binding.PreviousButton.setOnClickListener{
            quizViewModel.moveToPrevious()
            updateQuestion()
            repeatAnswers()
        }
        updateQuestion()



        binding.SubmitButton.setOnClickListener {
            if (quizViewModel.allQuestionsAnswered()) {
                quizScore(quizViewModel.correctAnswers)
            } else {
                Toast.makeText(
                    this,
                    "Answer all questions before submitting",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    private fun updateQuestion(){
        binding.textQuestion.setText(quizViewModel.currentQuestionText)
        repeatAnswers()
    }


    override fun onStart(){
        super.onStart()
        Log.d(TAG, "onStart() is called")
    }

    override fun onResume(){
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause(){
        super.onPause()
        Log.d(TAG, "onPause() is called")
    }

    override fun onDestroy(){
        super.onDestroy()
        Log.d(TAG, "onDestroy() is called")
    }

    override fun onStop(){
        super.onStop()
        Log.d(TAG, "onStop() is called")
    }

    private var correctAnswers = 0

    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswer = quizViewModel.currentQuestionAnswer
        val question = quizViewModel.currentQuestion

        val messageResId = when {
            question.cheated -> R.string.judgement_toast
            userAnswer == correctAnswer -> {
                quizViewModel.incrementCorrectAnswers()
                R.string.true_toast
            }
            else -> R.string.false_toast
        }

        Snackbar.make(findViewById(android.R.id.content), messageResId, Snackbar.LENGTH_SHORT).show()

        quizViewModel.setAnswered(true)
    }
    private fun repeatAnswers() {
        val question = quizViewModel.currentQuestion
        val answered = quizViewModel.getAnsweredState()
        binding.TrueButton.isEnabled = !question.answered
        binding.FalseButton.isEnabled = !question.answered
    }



    private fun quizScore(correctAnswers: Int) {
        val percentCorrect = (quizViewModel.correctAnswers.toDouble() / quizViewModel.totalQuestions) * 100.0
        Toast.makeText(
            this,
            "Your score: ${"%.2f".format(percentCorrect)}%",
            Toast.LENGTH_SHORT
        ).show()
    }
}