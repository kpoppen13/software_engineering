package com.example.hellokittyquiz

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.createSavedStateHandle


private const val TAG = "QuizViewModel"
const val CURRENT_INDEX_KEY = "CURRENT_INDEX_KEY"
const val IS_CHEATER_KEY = "IS_CHEATER_KEY"
class QuizViewModel(private val savedStateHandle: SavedStateHandle) : ViewModel() {

    // create a question bank so that it's an array of Question objects, each with the question
    // and its corresponding answer
    private val questionBank = listOf(
        Question(R.string.question1, true, false),
        Question(R.string.question2, false, false),
        Question(R.string.question3, true, false),
        Question(R.string.question4, true, false)

    )

    var isCheater: Boolean
        get() = questionBank[currentIndex].cheated
        set(value) {
            questionBank[currentIndex].cheated = value
        }

    var currentIndex: Int
        get() = savedStateHandle.get<Int>(CURRENT_INDEX_KEY) ?: 0
        set(value) {
            savedStateHandle[CURRENT_INDEX_KEY] = value
        }

    val currentQuestionAnswer: Boolean
        get() = questionBank[currentIndex].answer
    val currentQuestionText: Int
        get() = questionBank[currentIndex].textResId
    val currentQuestion: Question
        get() = questionBank[currentIndex]
    var correctAnswers = 0
    val totalQuestions: Int
        get() = questionBank.size

    fun moveToNext(){
        currentIndex = (currentIndex + 1) % questionBank.size
    }
    fun moveToPrevious() {
        currentIndex =
            if (currentIndex == 0) questionBank.size - 1
            else currentIndex - 1
    }

    fun setAnswered(answered: Boolean) {
        questionBank[currentIndex].answered = answered
        savedStateHandle["QUESTION_${currentIndex}_ANSWERED"] = answered
    }

    fun getAnsweredState(): Boolean {
        return savedStateHandle.get("QUESTION_${currentIndex}_ANSWERED") ?: false
    }

    fun allQuestionsAnswered():Boolean{
        return questionBank.all{it.answered}
    }

    fun incrementCorrectAnswers(){
        correctAnswers++
    }

}
