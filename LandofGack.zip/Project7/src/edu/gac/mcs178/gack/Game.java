package edu.gac.mcs178.gack;

import edu.gac.mcs178.gack.ui.GraphicalUserInterface;

public class Game {
	
	public static void main(String[] args) {
		GraphicalUserInterface.main(args);
	}
}
