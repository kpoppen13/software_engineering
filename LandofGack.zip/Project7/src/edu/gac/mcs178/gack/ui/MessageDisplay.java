package edu.gac.mcs178.gack.ui;

public interface MessageDisplay {
	public void displayMessage(String message);
}
