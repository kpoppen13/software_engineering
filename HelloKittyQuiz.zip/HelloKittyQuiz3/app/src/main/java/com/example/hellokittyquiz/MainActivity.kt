package com.example.hellokittyquiz

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import com.google.android.material.snackbar.Snackbar
import com.example.hellokittyquiz.databinding.ActivityMainBinding

// add some information that records the progress on my log
private const val TAG = "Main Activity Recording"


class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var nextButton: Button
    private lateinit var previousButton: Button

    private lateinit var binding: ActivityMainBinding

    // create a question bank so that it's an array of Question objects, each with the question
    // and its corresponding answer

    private val questionBank = listOf(
        Question(R.string.question1, true),
        Question(R.string.question2, false),
        Question(R.string.question3, true),
        Question(R.string.question4, true)

    )
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "OnCreate(Bundle?) called")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //trueButton = findViewById(R.id.TrueButton)
        //falseButton = findViewById(R.id.FalseButton)
        nextButton = findViewById(R.id.NextButton)

        binding.TrueButton.setOnClickListener { view: View ->

            //trueButton.setOnClickListener { view: View ->
            /*Toast.makeText(
                this,
                R.string.false_toast,
                Toast.LENGTH_SHORT
            ).show()*/
            checkAnswer(true)
        }


        binding.FalseButton.setOnClickListener {view: View ->
        //falseButton.setOnClickListener { view: View ->
        /*Toast.makeText(
            this,
            R.string.true_toast,
            Toast.LENGTH_SHORT
        ).show()*/
            checkAnswer(false)

        }

        binding.NextButton.setOnClickListener {
            currentIndex = (currentIndex +1) % questionBank.size
            updateQuestion()
            //val questionTextResId = questionBank[currentIndex].textResId
            //binding.textQuestion.setText(questionTextResId)
        }

        //val questionTextResId = questionBank[currentIndex].textResId
        //binding.textQuestion.setText(questionTextResId)

        updateQuestion()

        binding.textQuestion.setOnClickListener{
            currentIndex = (currentIndex + 1) % questionBank.size
            updateQuestion()
        }
        updateQuestion()
        binding.PreviousButton.setOnClickListener{
            if (currentIndex == 0){
                currentIndex = questionBank.size -1
            }
            else{
                currentIndex -= 1
            }
            
            updateQuestion()
        }
        updateQuestion()
        }
    private fun updateQuestion(){
        val questionTextResId = questionBank[currentIndex].textResId
        binding.textQuestion.setText(questionTextResId)
    }


    override fun onStart(){
        super.onStart()
        Log.d(TAG, "onStart() is called")
    }

    override fun onResume(){
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause(){
        super.onPause()
        Log.d(TAG, "onPause() is called")
    }

    override fun onDestroy(){
        super.onDestroy()
        Log.d(TAG, "onDestroy() is called")
    }

    override fun onStop(){
        super.onStop()
        Log.d(TAG, "onStop() is called")
    }


    private fun checkAnswer(userAnswer: Boolean){
        val correctAnswer = questionBank[currentIndex].answer

        val messageResId = if (userAnswer == correctAnswer){
            R.string.true_toast}
        else{
            R.string.false_toast}
        //Toast.makeText(this,messageResId, Toast.LENGTH_SHORT).show()
        Snackbar.make(findViewById(android.R.id.content), messageResId, Snackbar.LENGTH_SHORT).show()

        }
    }