package com.example.hellokittyquiz

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.hellokittyquiz.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

// add some information that records the progress on my log
private const val TAG = "Main Activity Recording"


class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var nextButton: Button
    private lateinit var previousButton: Button

    private lateinit var binding: ActivityMainBinding

    // create a question bank so that it's an array of Question objects, each with the question
    // and its corresponding answer

    private val questionBank = listOf(
        Question(R.string.question1, true, false),
        Question(R.string.question2, false, false),
        Question(R.string.question3, true, false),
        Question(R.string.question4, true, false)

    )
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "OnCreate(Bundle?) called")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //trueButton = findViewById(R.id.TrueButton)
        //falseButton = findViewById(R.id.FalseButton)

        nextButton = findViewById(R.id.NextButton)

        binding.TrueButton.setOnClickListener { view: View ->

            //trueButton.setOnClickListener { view: View ->
            /*Toast.makeText(
                this,
                R.string.false_toast,
                Toast.LENGTH_SHORT
            ).show()*/
            binding.TrueButton.isEnabled = false
            binding.FalseButton.isEnabled = false
            questionBank[currentIndex].answered = true
            checkAnswer(true)
        }

        binding.FalseButton.setOnClickListener {view: View ->
        //falseButton.setOnClickListener { view: View ->
        /*Toast.makeText(
            this,
            R.string.true_toast,
            Toast.LENGTH_SHORT
        ).show()*/

            binding.TrueButton.isEnabled = false
            binding.FalseButton.isEnabled = false
            questionBank[currentIndex].answered = true
            checkAnswer(false)

        }

        binding.NextButton.setOnClickListener {
            currentIndex = (currentIndex +1) % questionBank.size
            repeatAnswers(currentIndex)
            //val questionTextResId = questionBank[currentIndex].textResId
            //binding.textQuestion.setText(questionTextResId)

            updateQuestion()
        }




        //val questionTextResId = questionBank[currentIndex].textResId
        //binding.textQuestion.setText(questionTextResId)

        updateQuestion()

        binding.textQuestion.setOnClickListener{
            currentIndex = (currentIndex + 1) % questionBank.size
            updateQuestion()
        }
        updateQuestion()
        binding.PreviousButton.setOnClickListener{
            if (currentIndex == 0){
                currentIndex = questionBank.size -1
            }
            else{
                currentIndex -= 1
            }
            repeatAnswers(currentIndex)
            updateQuestion()
        }
        updateQuestion()

        binding.SubmitButton.setOnClickListener {
            if(questionBank.all{it.answered}){ // this line checks if all the questions have been answered
                quizScore((correctAnswers)) // if yes, then calculate the quiz score using the function
            }
            else{ // if not all the questions have been answered, then the user can go back and answer them all
                Toast.makeText(
                    this,
                    "Answer all questions before submitting",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }



        }
    private fun updateQuestion(){
        val questionTextResId = questionBank[currentIndex].textResId
        binding.textQuestion.setText(questionTextResId)
    }


    override fun onStart(){
        super.onStart()
        Log.d(TAG, "onStart() is called")
    }

    override fun onResume(){
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause(){
        super.onPause()
        Log.d(TAG, "onPause() is called")
    }

    override fun onDestroy(){
        super.onDestroy()
        Log.d(TAG, "onDestroy() is called")
    }

    override fun onStop(){
        super.onStop()
        Log.d(TAG, "onStop() is called")
    }

    private var correctAnswers = 0

    private fun checkAnswer(userAnswer: Boolean){
        val correctAnswer = questionBank[currentIndex].answer
        val messageResId = if (userAnswer == correctAnswer){
            correctAnswers ++
            R.string.true_toast}
        else{
            R.string.false_toast}
        //Toast.makeText(this,messageResId, Toast.LENGTH_SHORT).show()
        Snackbar.make(findViewById(android.R.id.content), messageResId, Snackbar.LENGTH_SHORT).show()

        }
    private fun repeatAnswers(index:Int){
        if(questionBank[index].answered){
            binding.TrueButton.isEnabled = false
            binding.FalseButton.isEnabled = false
        }
        else{
            binding.TrueButton.isEnabled = true
            binding.FalseButton.isEnabled = true
        }
    }

    private var percentCorrect = 0.0
    private fun quizScore(correctAnswers: Int){

        //  add up all the correct answers and divide by total number of questions in questionBank
        // multiply by 100 to get the percentage
        percentCorrect = (correctAnswers.toDouble() /  questionBank.size) * 100.0
        // then read a toast that gives percentage score
        Toast.makeText(
            this,
            "Your score: ${"%.2f".format(percentCorrect)}%",
            Toast.LENGTH_SHORT
        ).show()

    }


    }